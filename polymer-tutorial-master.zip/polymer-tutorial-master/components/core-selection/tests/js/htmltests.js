htmlSuite('core-selection', function() {
  htmlTest('html/core-selection-basic.html');
  htmlTest('html/core-selection-multi.html');
});