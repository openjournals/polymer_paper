paper-focusable
===============

See the [component page](http://www.polymer-project.org/docs/elements/paper-elements.html#paper-focusable) for more information.
