core-media-query
================

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-media-query) for more information.
